import os


def handler(event, context):
    env_var = os.getenv('ENV_VAR_TEST')
    return {
        'statusCode': 200,
        'message': env_var
    }
